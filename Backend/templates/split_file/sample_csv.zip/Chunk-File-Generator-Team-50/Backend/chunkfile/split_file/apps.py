from django.apps import AppConfig


class SplitfileConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'split_file'
