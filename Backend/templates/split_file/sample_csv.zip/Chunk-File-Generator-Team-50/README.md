# Chunk-File-Generator-Team-50

# Introduction
Chunk Files is an online platform that allows individuals to upload large CSV or JSON files and split the dataset in the uploaded CSV or JSON file into multiple files.
